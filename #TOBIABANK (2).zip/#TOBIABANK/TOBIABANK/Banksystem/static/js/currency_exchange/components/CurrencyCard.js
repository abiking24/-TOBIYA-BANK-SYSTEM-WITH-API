import React from 'react';
import { Card, CardContent, Typography, IconButton, Box, Tooltip } from '@mui/material';
import { Favorite, FavoriteBorder } from '@mui/icons-material';

const CurrencyCard = ({ 
  currency, 
  isFavorite = false, 
  onToggleFavorite, 
  onClick,
  showFavorite = true,
  exchangeRate,
  baseCurrency,
  amount = 1
}) => {
  const handleFavoriteClick = (e) => {
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(currency);
    }
  };

  const handleClick = () => {
    if (onClick) {
      onClick(currency);
    }
  };

  return (
    <Card 
      onClick={handleClick}
      sx={{ 
        cursor: 'pointer', 
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 3,
        },
      }}
      elevation={1}
    >
      <CardContent sx={{ flexGrow: 1 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Box display="flex" alignItems="center" mb={1}>
              <Typography 
                variant="h5" 
                component="div"
                sx={{ 
                  fontWeight: 'bold',
                  mr: 1,
                  display: 'flex',
                  alignItems: 'center'
                }}
              >
                <Box component="span" sx={{ mr: 1, fontSize: '1.5rem' }}>
                  {currency.flag_emoji || '🌐'}
                </Box>
                {currency.code}
              </Typography>
              {showFavorite && onToggleFavorite && (
                <Tooltip title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}>
                  <IconButton 
                    onClick={handleFavoriteClick}
                    size="small"
                    color={isFavorite ? 'error' : 'default'}
                    sx={{ ml: 1 }}
                  >
                    {isFavorite ? <Favorite fontSize="small" /> : <FavoriteBorder fontSize="small" />}
                  </IconButton>
                </Tooltip>
              )}
            </Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              {currency.name}
            </Typography>
          </Box>
          
          {exchangeRate !== undefined && baseCurrency && (
            <Box textAlign="right">
              <Typography variant="body2" color="text.secondary">
                1 {baseCurrency} =
              </Typography>
              <Typography variant="h6" color="primary" fontWeight="bold">
                {exchangeRate.toFixed(6)} {currency.code}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {amount} {currency.code} = {(amount / exchangeRate).toFixed(6)} {baseCurrency}
              </Typography>
            </Box>
          )}
        </Box>
        
        {currency.symbol && (
          <Box mt={1}>
            <Typography variant="caption" color="text.secondary">
              Symbol: {currency.symbol}
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default CurrencyCard;
