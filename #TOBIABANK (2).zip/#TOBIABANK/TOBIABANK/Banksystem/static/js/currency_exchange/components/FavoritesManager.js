import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  IconButton, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  Button,
  TextField,
  Divider,
  Tooltip,
  Paper,
  Snackbar,
  Alert
} from '@mui/material';
import { 
  Delete as DeleteIcon, 
  Edit as EditIcon, 
  Star as StarIcon,
  StarBorder as StarBorderIcon
} from '@mui/icons-material';
import axios from 'axios';
import CurrencyCard from './CurrencyCard';

const FavoritesManager = ({ 
  favorites, 
  onUpdateFavorites, 
  onSelectPair,
  baseCurrency,
  exchangeRates
}) => {
  const [editingFavorite, setEditingFavorite] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [notes, setNotes] = useState({});
  const [editingNote, setEditingNote] = useState({ id: null, note: '' });

  useEffect(() => {
    // Load saved notes from localStorage
    const savedNotes = JSON.parse(localStorage.getItem('currencyNotes') || '{}');
    setNotes(savedNotes);
  }, []);

  const handleDeleteFavorite = async (favoriteId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) throw new Error('Authentication required');
      
      await axios.delete(`/api/currency/favorites/${favoriteId}/`, {
        headers: { 'Authorization': `Token ${token}` }
      });
      
      onUpdateFavorites(favorites.filter(fav => fav.id !== favoriteId));
      setSnackbar({
        open: true,
        message: 'Removed from favorites',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error removing favorite:', error);
      setSnackbar({
        open: true,
        message: 'Failed to remove favorite',
        severity: 'error'
      });
    } finally {
      setDeleteConfirm(null);
    }
  };

  const handleUpdateNote = (favoriteId, note) => {
    const updatedNotes = { ...notes, [favoriteId]: note };
    setNotes(updatedNotes);
    localStorage.setItem('currencyNotes', JSON.stringify(updatedNotes));
    setEditingNote({ id: null, note: '' });
    
    setSnackbar({
      open: true,
      message: 'Note saved',
      severity: 'success'
    });
  };

  const handleRateFavorite = async (favoriteId, newRating) => {
    try {
      // In a real app, you would save this to your backend
      const ratedFavorites = JSON.parse(localStorage.getItem('ratedFavorites') || '{}');
      ratedFavorites[favoriteId] = newRating;
      localStorage.setItem('ratedFavorites', JSON.stringify(ratedFavorites));
      
      setSnackbar({
        open: true,
        message: 'Rating saved',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error saving rating:', error);
    }
  };

  const getExchangeRate = (fromCurrency, toCurrency) => {
    if (!exchangeRates) return null;
    const rate = exchangeRates[`${fromCurrency}_${toCurrency}`];
    return rate || null;
  };

  if (favorites.length === 0) {
    return (
      <Box textAlign="center" py={4}>
        <StarBorderIcon color="action" sx={{ fontSize: 48, mb: 2 }} />
        <Typography variant="h6" color="textSecondary" gutterBottom>
          No favorite currency pairs yet
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Add currency pairs to your favorites to see them here
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Grid container spacing={3}>
        {favorites.map((favorite) => {
          const rate = getExchangeRate(favorite.from_currency.code, favorite.to_currency.code);
          const note = notes[favorite.id] || '';
          const isEditing = editingNote.id === favorite.id;
          
          return (
            <Grid item xs={12} sm={6} md={4} key={favorite.id}>
              <Paper 
                elevation={2} 
                sx={{ 
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  overflow: 'hidden',
                  border: '1px solid',
                  borderColor: 'divider',
                  '&:hover': {
                    boxShadow: 3,
                  },
                }}
              >
                <Box 
                  p={2} 
                  sx={{ 
                    bgcolor: 'primary.main',
                    color: 'primary.contrastText',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <Box>
                    <Typography variant="subtitle1" fontWeight="bold">
                      {favorite.from_currency.code} / {favorite.to_currency.code}
                    </Typography>
                    <Typography variant="caption">
                      {favorite.from_currency.name} to {favorite.to_currency.name}
                    </Typography>
                  </Box>
                  <Box>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <IconButton 
                        key={star} 
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRateFavorite(favorite.id, star);
                        }}
                        sx={{ color: 'gold' }}
                      >
                        <StarIcon fontSize="small" />
                      </IconButton>
                    ))}
                  </Box>
                </Box>
                
                <Box p={2} flexGrow={1}>
                  {rate !== null && (
                    <Box mb={2}>
                      <Typography variant="h5" align="center" gutterBottom>
                        1 {favorite.from_currency.code} = {rate.toFixed(6)} {favorite.to_currency.code}
                      </Typography>
                      <Typography variant="body2" color="textSecondary" align="center">
                        1 {favorite.to_currency.code} = {(1 / rate).toFixed(6)} {favorite.from_currency.code}
                      </Typography>
                    </Box>
                  )}
                  
                  <Divider sx={{ my: 2 }} />
                  
                  {isEditing ? (
                    <Box mb={2}>
                      <TextField
                        fullWidth
                        multiline
                        rows={3}
                        variant="outlined"
                        value={editingNote.note}
                        onChange={(e) => setEditingNote({ ...editingNote, note: e.target.value })}
                        placeholder="Add a note about this currency pair..."
                      />
                      <Box mt={1} display="flex" justifyContent="flex-end">
                        <Button 
                          size="small" 
                          onClick={() => setEditingNote({ id: null, note: '' })}
                          sx={{ mr: 1 }}
                        >
                          Cancel
                        </Button>
                        <Button 
                          variant="contained" 
                          size="small" 
                          color="primary"
                          onClick={() => handleUpdateNote(favorite.id, editingNote.note)}
                        >
                          Save
                        </Button>
                      </Box>
                    </Box>
                  ) : (
                    <Box 
                      onClick={() => setEditingNote({ id: favorite.id, note: note })}
                      sx={{ 
                        p: 1, 
                        minHeight: 80,
                        border: '1px dashed',
                        borderColor: 'divider',
                        borderRadius: 1,
                        cursor: 'pointer',
                        '&:hover': {
                          backgroundColor: 'action.hover',
                        },
                      }}
                    >
                      {note ? (
                        <Typography variant="body2" whiteSpace="pre-wrap">
                          {note}
                        </Typography>
                      ) : (
                        <Typography 
                          variant="body2" 
                          color="textSecondary"
                          fontStyle="italic"
                        >
                          Click to add a note...
                        </Typography>
                      )}
                    </Box>
                  )}
                </Box>
                
                <Box 
                  p={1} 
                  display="flex" 
                  justifyContent="space-between"
                  borderTop="1px solid"
                  borderColor="divider"
                >
                  <Box>
                    <Tooltip title="Convert">
                      <IconButton 
                        size="small"
                        onClick={() => onSelectPair(favorite.from_currency.code, favorite.to_currency.code)}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                  <Box>
                    <Tooltip title="Remove from favorites">
                      <IconButton 
                        size="small" 
                        color="error"
                        onClick={() => setDeleteConfirm(favorite.id)}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </Paper>
              
              {/* Delete confirmation dialog */}
              <Dialog
                open={deleteConfirm === favorite.id}
                onClose={() => setDeleteConfirm(null)}
                maxWidth="xs"
                fullWidth
              >
                <DialogTitle>Remove from favorites?</DialogTitle>
                <DialogContent>
                  <Typography>
                    Are you sure you want to remove {favorite.from_currency.code}/{favorite.to_currency.code} from your favorites?
                  </Typography>
                </DialogContent>
                <DialogActions>
                  <Button onClick={() => setDeleteConfirm(null)}>Cancel</Button>
                  <Button 
                    onClick={() => handleDeleteFavorite(favorite.id)}
                    color="error"
                    variant="contained"
                  >
                    Remove
                  </Button>
                </DialogActions>
              </Dialog>
            </Grid>
          );
        })}
      </Grid>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          variant="filled"
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default FavoritesManager;
