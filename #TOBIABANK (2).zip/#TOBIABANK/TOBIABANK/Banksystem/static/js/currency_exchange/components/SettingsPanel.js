import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  FormGroup,
  FormControlLabel,
  Switch,
  Divider,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Paper,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  InputAdornment,
  Slider,
  useTheme,
  useMediaQuery
} from '@mui/material';
import {
  Save as SaveIcon,
  Notifications as NotificationsIcon,
  Language as LanguageIcon,
  Palette as PaletteIcon,
  Info as InfoIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon
} from '@mui/icons-material';

const SettingsPanel = ({ 
  open, 
  onClose, 
  onSave, 
  settings: initialSettings,
  availableCurrencies = []
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [activeTab, setActiveTab] = useState(0);
  const [settings, setSettings] = useState(initialSettings);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  const [alerts, setAlerts] = useState(initialSettings.rateAlerts || []);
  const [alertDialog, setAlertDialog] = useState({ open: false, alert: null, isNew: true });
  const [newAlert, setNewAlert] = useState({
    id: null,
    fromCurrency: 'USD',
    toCurrency: 'EUR',
    targetRate: '',
    condition: 'above',
    isActive: true
  });

  // Initialize settings when they change
  useEffect(() => {
    setSettings(initialSettings);
    setAlerts(initialSettings.rateAlerts || []);
  }, [initialSettings]);

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSave = () => {
    const updatedSettings = {
      ...settings,
      rateAlerts: alerts
    };
    
    onSave(updatedSettings);
    setNotification({
      open: true,
      message: 'Settings saved successfully',
      severity: 'success'
    });
  };

  const handleAddAlert = () => {
    setNewAlert({
      id: Date.now(),
      fromCurrency: 'USD',
      toCurrency: 'EUR',
      targetRate: '',
      condition: 'above',
      isActive: true
    });
    setAlertDialog({ open: true, alert: null, isNew: true });
  };

  const handleEditAlert = (alert) => {
    setNewAlert(alert);
    setAlertDialog({ open: true, alert, isNew: false });
  };

  const handleSaveAlert = () => {
    if (!newAlert.fromCurrency || !newAlert.toCurrency || !newAlert.targetRate) {
      setNotification({
        open: true,
        message: 'Please fill in all fields',
        severity: 'error'
      });
      return;
    }

    if (alertDialog.isNew) {
      setAlerts(prev => [...prev, { ...newAlert, id: Date.now() }]);
    } else {
      setAlerts(prev => 
        prev.map(a => a.id === newAlert.id ? newAlert : a)
      );
    }
    
    setAlertDialog({ ...alertDialog, open: false });
    setNotification({
      open: true,
      message: `Rate alert ${alertDialog.isNew ? 'added' : 'updated'} successfully`,
      severity: 'success'
    });
  };

  const handleDeleteAlert = (id) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
    setNotification({
      open: true,
      message: 'Alert deleted successfully',
      severity: 'success'
    });
  };

  const handleClose = () => {
    onClose();
    // Reset to initial settings when closing without saving
    setSettings(initialSettings);
    setAlerts(initialSettings.rateAlerts || []);
  };

  const renderGeneralSettings = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        <LanguageIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
        General Settings
      </Typography>
      
      <FormGroup sx={{ mb: 3 }}>
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel id="default-from-currency-label">Default From Currency</InputLabel>
          <Select
            labelId="default-from-currency-label"
            value={settings.defaultFromCurrency}
            onChange={(e) => handleSettingChange('defaultFromCurrency', e.target.value)}
            label="Default From Currency"
          >
            {availableCurrencies.map(currency => (
              <MenuItem key={`from-${currency.code}`} value={currency.code}>
                {currency.flag_emoji} {currency.code} - {currency.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel id="default-to-currency-label">Default To Currency</InputLabel>
          <Select
            labelId="default-to-currency-label"
            value={settings.defaultToCurrency}
            onChange={(e) => handleSettingChange('defaultToCurrency', e.target.value)}
            label="Default To Currency"
          >
            {availableCurrencies.map(currency => (
              <MenuItem key={`to-${currency.code}`} value={currency.code}>
                {currency.flag_emoji} {currency.code} - {currency.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.autoUpdateRates}
              onChange={(e) => handleSettingChange('autoUpdateRates', e.target.checked)}
            />
          }
          label="Auto-update exchange rates"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.showCurrencySymbols}
              onChange={(e) => handleSettingChange('showCurrencySymbols', e.target.checked)}
            />
          }
          label="Show currency symbols"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.showHistoricalCharts}
              onChange={(e) => handleSettingChange('showHistoricalCharts', e.target.checked)}
            />
          }
          label="Show historical charts"
        />
      </FormGroup>
      
      <Divider sx={{ my: 3 }} />
      
      <Typography variant="h6" gutterBottom>
        Number Formatting
      </Typography>
      
      <FormControl fullWidth sx={{ mb: 2 }}>
        <InputLabel id="number-format-style-label">Number Format</InputLabel>
        <Select
          labelId="number-format-style-label"
          value={settings.numberFormat}
          onChange={(e) => handleSettingChange('numberFormat', e.target.value)}
          label="Number Format"
        >
          <MenuItem value="en-US">1,234,567.89 (US)</MenuItem>
          <MenuItem value="de-DE">1.234.567,89 (EU)</MenuItem>
          <MenuItem value="fr-FR">1 234 567,89 (FR)</MenuItem>
          <MenuItem value="ja-JP">1,234,567.89 (JP)</MenuItem>
        </Select>
      </FormControl>
      
      <FormControlLabel
        control={
          <Switch
            checked={settings.useGrouping}
            onChange={(e) => handleSettingChange('useGrouping', e.target.checked)}
          />
        }
        label="Use thousand separators"
      />
    </Box>
  );

  const renderAppearanceSettings = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        <PaletteIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
        Appearance
      </Typography>
      
      <FormControl fullWidth sx={{ mb: 3 }}>
        <InputLabel id="theme-preference-label">Theme</InputLabel>
        <Select
          labelId="theme-preference-label"
          value={settings.theme}
          onChange={(e) => handleSettingChange('theme', e.target.value)}
          label="Theme"
        >
          <MenuItem value="light">Light</MenuItem>
          <MenuItem value="dark">Dark</MenuItem>
          <MenuItem value="system">System Default</MenuItem>
        </Select>
      </FormControl>
      
      <Typography variant="subtitle2" gutterBottom>
        Chart Display
      </Typography>
      
      <FormGroup sx={{ mb: 2 }}>
        <FormControlLabel
          control={
            <Switch
              checked={settings.showGridLines}
              onChange={(e) => handleSettingChange('showGridLines', e.target.checked)}
            />
          }
          label="Show grid lines"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.showDataPoints}
              onChange={(e) => handleSettingChange('showDataPoints', e.target.checked)}
            />
          }
          label="Show data points"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.showLegend}
              onChange={(e) => handleSettingChange('showLegend', e.target.checked)}
            />
          }
          label="Show legend"
        />
      </FormGroup>
      
      <Box sx={{ mt: 3, mb: 2 }}>
        <Typography id="chart-line-width-label" gutterBottom>
          Chart line width: {settings.chartLineWidth}px
        </Typography>
        <Slider
          value={settings.chartLineWidth}
          onChange={(e, value) => handleSettingChange('chartLineWidth', value)}
          aria-labelledby="chart-line-width-label"
          valueLabelDisplay="auto"
          step={0.5}
          marks
          min={1}
          max={5}
        />
      </Box>
      
      <Box sx={{ mt: 3, mb: 2 }}>
        <Typography id="chart-animation-speed-label" gutterBottom>
          Animation speed: {settings.chartAnimationSpeed}ms
        </Typography>
        <Slider
          value={settings.chartAnimationSpeed}
          onChange={(e, value) => handleSettingChange('chartAnimationSpeed', value)}
          aria-labelledby="chart-animation-speed-label"
          valueLabelDisplay="auto"
          step={100}
          min={0}
          max={2000}
        />
      </Box>
    </Box>
  );

  const renderNotificationsSettings = () => (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6">
          <NotificationsIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
          Rate Alerts
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={handleAddAlert}
          size={isMobile ? 'small' : 'medium'}
        >
          {isMobile ? 'Add' : 'Add Alert'}
        </Button>
      </Box>
      
      <Typography variant="body2" color="textSecondary" paragraph>
        Get notified when exchange rates reach your target values.
      </Typography>
      
      {alerts.length === 0 ? (
        <Box textAlign="center" py={4}>
          <NotificationsIcon color="action" sx={{ fontSize: 48, mb: 2 }} />
          <Typography variant="body1" color="textSecondary">
            No rate alerts set up yet
          </Typography>
          <Button 
            variant="outlined" 
            color="primary" 
            startIcon={<AddIcon />}
            onClick={handleAddAlert}
            sx={{ mt: 2 }}
          >
            Create Alert
          </Button>
        </Box>
      ) : (
        <List>
          {alerts.map((alert) => (
            <Paper key={alert.id} variant="outlined" sx={{ mb: 1 }}>
              <ListItem>
                <ListItemText
                  primary={
                    <Box display="flex" alignItems="center">
                      <Typography component="span" fontWeight="medium">
                        {alert.fromCurrency} / {alert.toCurrency}
                      </Typography>
                      <Typography 
                        component="span" 
                        variant="body2" 
                        color="textSecondary"
                        sx={{ ml: 1 }}
                      >
                        {alert.condition === 'above' ? 'above' : 'below'} {alert.targetRate}
                      </Typography>
                    </Box>
                  }
                  secondary={
                    <Box display="flex" alignItems="center">
                      <Box 
                        component="span" 
                        sx={{
                          width: 10,
                          height: 10,
                          borderRadius: '50%',
                          bgcolor: alert.isActive ? 'success.main' : 'grey.500',
                          mr: 1,
                          display: 'inline-block'
                        }}
                      />
                      <Typography component="span" variant="caption">
                        {alert.isActive ? 'Active' : 'Inactive'}
                      </Typography>
                    </Box>
                  }
                />
                <ListItemSecondaryAction>
                  <IconButton 
                    edge="end" 
                    aria-label="edit" 
                    onClick={() => handleEditAlert(alert)}
                    size="small"
                    sx={{ mr: 1 }}
                  >
                    <EditIcon fontSize="small" />
                  </IconButton>
                  <IconButton 
                    edge="end" 
                    aria-label="delete" 
                    onClick={() => handleDeleteAlert(alert.id)}
                    size="small"
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </ListItemSecondaryAction>
              </ListItem>
            </Paper>
          ))}
        </List>
      )}
      
      <Divider sx={{ my: 3 }} />
      
      <Typography variant="h6" gutterBottom>
        Notification Preferences
      </Typography>
      
      <FormGroup>
        <FormControlLabel
          control={
            <Switch
              checked={settings.emailNotifications}
              onChange={(e) => handleSettingChange('emailNotifications', e.target.checked)}
            />
          }
          label="Email notifications"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.pushNotifications}
              onChange={(e) => handleSettingChange('pushNotifications', e.target.checked)}
            />
          }
          label="Push notifications"
          sx={{ mb: 1 }}
        />
        
        <FormControlLabel
          control={
            <Switch
              checked={settings.soundEnabled}
              onChange={(e) => handleSettingChange('soundEnabled', e.target.checked)}
            />
          }
          label="Enable sounds"
        />
      </FormGroup>
      
      <Box sx={{ mt: 3 }}>
        <Typography id="notification-volume-label" gutterBottom>
          Notification volume
        </Typography>
        <Slider
          value={settings.notificationVolume}
          onChange={(e, value) => handleSettingChange('notificationVolume', value)}
          aria-labelledby="notification-volume-label"
          valueLabelDisplay="auto"
          step={10}
          min={0}
          max={100}
          disabled={!settings.soundEnabled}
        />
      </Box>
    </Box>
  );

  const renderAboutSection = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        <InfoIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
        About Currency Exchange
      </Typography>
      
      <Box mb={3}>
        <Typography variant="body1" paragraph>
          Currency Exchange helps you track and convert between different world currencies with up-to-date exchange rates.
        </Typography>
        
        <Typography variant="subtitle2" gutterBottom>
          Version
        </Typography>
        <Typography variant="body2" color="textSecondary" paragraph>
          1.0.0
        </Typography>
        
        <Typography variant="subtitle2" gutterBottom>
          Last Updated
        </Typography>
        <Typography variant="body2" color="textSecondary" paragraph>
          {new Date().toLocaleDateString()}
        </Typography>
        
        <Typography variant="subtitle2" gutterBottom>
          Data Sources
        </Typography>
        <Typography variant="body2" color="textSecondary" paragraph>
          Exchange rates are provided by various financial data providers and are updated every hour.
        </Typography>
        
        <Typography variant="subtitle2" gutterBottom>
          Terms & Privacy
        </Typography>
        <Typography variant="body2" color="textSecondary" paragraph>
          By using this application, you agree to our Terms of Service and Privacy Policy.
        </Typography>
      </Box>
      
      <Divider sx={{ my: 3 }} />
      
      <Typography variant="subtitle1" gutterBottom>
        Contact Support
      </Typography>
      <Typography variant="body2" color="textSecondary" paragraph>
        If you have any questions or need assistance, please contact our support team at support@tobiabank.com
      </Typography>
    </Box>
  );

  return (
    <Dialog 
      open={open} 
      onClose={handleClose}
      fullWidth
      maxWidth="md"
      fullScreen={isMobile}
      aria-labelledby="settings-dialog-title"
    >
      <DialogTitle id="settings-dialog-title">
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <span>Settings</span>
          <Box>
            <Button 
              onClick={handleSave} 
              variant="contained" 
              color="primary"
              startIcon={<SaveIcon />}
              size={isMobile ? 'small' : 'medium'}
            >
              Save
            </Button>
          </Box>
        </Box>
      </DialogTitle>
      
      <DialogContent dividers>
        <Box sx={{ width: '100%' }}>
          <Tabs 
            value={activeTab} 
            onChange={(e, newValue) => setActiveTab(newValue)}
            variant={isMobile ? 'fullWidth' : 'standard'}
            scrollButtons="auto"
            allowScrollButtonsMobile
            sx={{ mb: 3 }}
          >
            <Tab label="General" />
            <Tab label="Appearance" />
            <Tab label="Notifications" />
            <Tab label="About" />
          </Tabs>
          
          <Box sx={{ p: isMobile ? 0 : 2 }}>
            {activeTab === 0 && renderGeneralSettings()}
            {activeTab === 1 && renderAppearanceSettings()}
            {activeTab === 2 && renderNotificationsSettings()}
            {activeTab === 3 && renderAboutSection()}
          </Box>
        </Box>
      </DialogContent>
      
      <DialogActions sx={{ p: 2, justifyContent: 'space-between' }}>
        <Button onClick={handleClose} color="inherit">
          Cancel
        </Button>
        <Box>
          <Button 
            onClick={handleSave} 
            variant="contained" 
            color="primary"
            startIcon={<SaveIcon />}
          >
            Save Changes
          </Button>
        </Box>
      </DialogActions>
      
      {/* Alert Dialog */}
      <Dialog 
        open={alertDialog.open} 
        onClose={() => setAlertDialog({ ...alertDialog, open: false })}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>
          {alertDialog.isNew ? 'Add New Alert' : 'Edit Alert'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel>From Currency</InputLabel>
                <Select
                  value={newAlert.fromCurrency}
                  onChange={(e) => setNewAlert({ ...newAlert, fromCurrency: e.target.value })}
                  label="From Currency"
                >
                  {availableCurrencies.map(currency => (
                    <MenuItem key={`alert-from-${currency.code}`} value={currency.code}>
                      {currency.flag_emoji} {currency.code}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel>To Currency</InputLabel>
                <Select
                  value={newAlert.toCurrency}
                  onChange={(e) => setNewAlert({ ...newAlert, toCurrency: e.target.value })}
                  label="To Currency"
                >
                  {availableCurrencies
                    .filter(c => c.code !== newAlert.fromCurrency)
                    .map(currency => (
                      <MenuItem key={`alert-to-${currency.code}`} value={currency.code}>
                        {currency.flag_emoji} {currency.code}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel>Condition</InputLabel>
                <Select
                  value={newAlert.condition}
                  onChange={(e) => setNewAlert({ ...newAlert, condition: e.target.value })}
                  label="Condition"
                >
                  <MenuItem value="above">Rate is above</MenuItem>
                  <MenuItem value="below">Rate is below</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                margin="normal"
                label="Target Rate"
                type="number"
                value={newAlert.targetRate}
                onChange={(e) => setNewAlert({ ...newAlert, targetRate: e.target.value })}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      1 {newAlert.fromCurrency} =
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={newAlert.isActive}
                    onChange={(e) => setNewAlert({ ...newAlert, isActive: e.target.checked })}
                  />
                }
                label="Alert is active"
                sx={{ mt: 1 }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAlertDialog({ ...alertDialog, open: false })}>
            Cancel
          </Button>
          <Button 
            onClick={handleSaveAlert}
            variant="contained" 
            color="primary"
          >
            {alertDialog.isNew ? 'Add Alert' : 'Save Changes'}
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={notification.open}
        autoHideDuration={3000}
        onClose={() => setNotification({ ...notification, open: false })}
      >
        <Alert 
          onClose={() => setNotification({ ...notification, open: false })} 
          severity={notification.severity}
          variant="filled"
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Dialog>
  );
};

// Default settings
SettingsPanel.defaultProps = {
  settings: {
    defaultFromCurrency: 'USD',
    defaultToCurrency: 'EUR',
    autoUpdateRates: true,
    showCurrencySymbols: true,
    showHistoricalCharts: true,
    numberFormat: 'en-US',
    useGrouping: true,
    theme: 'system',
    showGridLines: true,
    showDataPoints: true,
    showLegend: true,
    chartLineWidth: 2,
    chartAnimationSpeed: 1000,
    emailNotifications: true,
    pushNotifications: true,
    soundEnabled: true,
    notificationVolume: 80,
    rateAlerts: []
  },
  availableCurrencies: [
    { code: 'USD', name: 'US Dollar', flag_emoji: '🇺🇸' },
    { code: 'EUR', name: 'Euro', flag_emoji: '🇪🇺' },
    { code: 'GBP', name: 'British Pound', flag_emoji: '🇬🇧' },
    { code: 'JPY', name: 'Japanese Yen', flag_emoji: '🇯🇵' },
    { code: 'AUD', name: 'Australian Dollar', flag_emoji: '🇦🇺' },
    { code: 'CAD', name: 'Canadian Dollar', flag_emoji: '🇨🇦' },
    { code: 'CHF', name: 'Swiss Franc', flag_emoji: '🇨🇭' },
    { code: 'CNY', name: 'Chinese Yuan', flag_emoji: '🇨🇳' },
  ]
};

export default SettingsPanel;
