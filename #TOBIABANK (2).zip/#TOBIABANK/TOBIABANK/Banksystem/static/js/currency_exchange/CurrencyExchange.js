import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import { 
  Card, CardContent, Typography, TextField, 
  Button, Grid, Paper, Tabs, Tab, Box,
  IconButton, Snackbar, CircularProgress, Select, MenuItem, FormControl, InputLabel
} from '@mui/material';
import { Favorite, FavoriteBorder, SwapHoriz, Search } from '@mui/icons-material';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const CurrencyExchange = () => {
  const [currencies, setCurrencies] = useState([]);
  const [amount, setAmount] = useState('1');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [exchangeRate, setExchangeRate] = useState(null);
  const [convertedAmount, setConvertedAmount] = useState(null);
  const [historicalData, setHistoricalData] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState(0);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  // Fetch currencies on component mount
  useEffect(() => {
    const fetchCurrencies = async () => {
      try {
        setLoading(true);
        const response = await axios.get('/api/currency/currencies/');
        setCurrencies(response.data);
        
        // If user is authenticated, fetch their favorites
        const token = localStorage.getItem('token');
        if (token) {
          try {
            const favResponse = await axios.get('/api/currency/favorites/', {
              headers: { 'Authorization': `Token ${token}` }
            });
            setFavorites(favResponse.data);
          } catch (err) {
            console.error('Error fetching favorites:', err);
          }
        }
      } catch (err) {
        setError('Failed to fetch currencies');
        console.error('Error fetching currencies:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCurrencies();
  }, []);

  // Check if current pair is in favorites
  useEffect(() => {
    const checkIfFavorite = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setIsFavorite(false);
        return;
      }

      try {
        const response = await axios.get('/api/currency/favorites/check_favorite/', {
          params: { from_currency: fromCurrency, to_currency: toCurrency },
          headers: { 'Authorization': `Token ${token}` }
        });
        setIsFavorite(response.data.is_favorite);
      } catch (err) {
        console.error('Error checking favorite status:', err);
      }
    };

    checkIfFavorite();
  }, [fromCurrency, toCurrency]);

  // Fetch exchange rate when currencies change
  useEffect(() => {
    const fetchExchangeRate = async () => {
      if (!fromCurrency || !toCurrency) return;
      
      try {
        setLoading(true);
        const response = await axios.get('/api/currency/exchange-rates/convert/', {
          params: { from_currency: fromCurrency, to_currency: toCurrency, amount: 1 }
        });
        
        setExchangeRate(response.data.rate);
        setConvertedAmount((parseFloat(amount) * response.data.rate).toFixed(6));
        
        // Fetch historical data
        const historicalResponse = await axios.get('/api/currency/exchange-rates/historical/', {
          params: { from_currency: fromCurrency, to_currency: toCurrency, days: 7 }
        });
        
        setHistoricalData({
          labels: historicalResponse.data.historical_data.map(item => item.date),
          datasets: [{
            label: `${fromCurrency} to ${toCurrency} Exchange Rate`,
            data: historicalResponse.data.historical_data.map(item => item.rate),
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
          }]
        });
      } catch (err) {
        setError('Failed to fetch exchange rate');
        console.error('Error fetching exchange rate:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchExchangeRate();
  }, [fromCurrency, toCurrency]);

  const handleConvert = () => {
    if (!exchangeRate) return;
    setConvertedAmount((parseFloat(amount) * exchangeRate).toFixed(6));
  };

  const handleSwap = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const toggleFavorite = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setSnackbar({ open: true, message: 'Please log in to save favorites', severity: 'warning' });
      return;
    }

    try {
      if (isFavorite) {
        // Find and remove favorite
        const favorite = favorites.find(
          fav => fav.from_currency.code === fromCurrency && fav.to_currency.code === toCurrency
        );
        if (favorite) {
          await axios.delete(`/api/currency/favorites/${favorite.id}/`, {
            headers: { 'Authorization': `Token ${token}` }
          });
        }
        setFavorites(favorites.filter(fav => fav.id !== favorite?.id));
      } else {
        // Add new favorite
        const response = await axios.post(
          '/api/currency/favorites/',
          { from_currency_code: fromCurrency, to_currency_code: toCurrency },
          { headers: { 'Authorization': `Token ${token}` }}
        );
        setFavorites([...favorites, response.data]);
      }
      setIsFavorite(!isFavorite);
      setSnackbar({
        open: true,
        message: isFavorite ? 'Removed from favorites' : 'Added to favorites',
        severity: 'success'
      });
    } catch (err) {
      console.error('Error updating favorites:', err);
      setSnackbar({
        open: true,
        message: 'Failed to update favorites',
        severity: 'error'
      });
    }
  };

  const handleFavoriteSelect = (fav) => {
    setFromCurrency(fav.from_currency.code);
    setToCurrency(fav.to_currency.code);
    setActiveTab(0);
  };

  const filteredCurrencies = currencies.filter(currency => 
    currency.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    currency.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Exchange Rate History (Last 7 Days)',
      },
    },
    scales: {
      y: {
        beginAtZero: false,
      },
    },
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Currency Exchange
      </Typography>
      
      <Tabs 
        value={activeTab} 
        onChange={(e, newValue) => setActiveTab(newValue)}
        sx={{ mb: 3 }}
      >
        <Tab label="Converter" />
        <Tab label="Favorites" />
        <Tab label="All Currencies" />
      </Tabs>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        message={snackbar.message}
      />

      {activeTab === 0 && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Currency Converter
                </Typography>
                
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} sm={5}>
                    <TextField
                      fullWidth
                      label="Amount"
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      variant="outlined"
                      margin="normal"
                    />
                  </Grid>
                  
                  <Grid item xs={12} sm={7}>
                    <FormControl fullWidth variant="outlined" margin="normal">
                      <InputLabel>From</InputLabel>
                      <Select
                        value={fromCurrency}
                        onChange={(e) => setFromCurrency(e.target.value)}
                        label="From"
                      >
                        {currencies.map((currency) => (
                          <MenuItem key={`from-${currency.code}`} value={currency.code}>
                            {currency.flag_emoji} {currency.code} - {currency.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  
                  <Grid item xs={12} textAlign="center">
                    <IconButton onClick={handleSwap} color="primary">
                      <SwapHoriz />
                    </IconButton>
                  </Grid>
                  
                  <Grid item xs={12} sm={7}>
                    <FormControl fullWidth variant="outlined" margin="normal">
                      <InputLabel>To</InputLabel>
                      <Select
                        value={toCurrency}
                        onChange={(e) => setToCurrency(e.target.value)}
                        label="To"
                      >
                        {currencies.map((currency) => (
                          <MenuItem key={`to-${currency.code}`} value={currency.code}>
                            {currency.flag_emoji} {currency.code} - {currency.name}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                  
                  <Grid item xs={12} sm={5}>
                    <TextField
                      fullWidth
                      label="Converted Amount"
                      value={convertedAmount || ''}
                      variant="outlined"
                      margin="normal"
                      InputProps={{
                        readOnly: true,
                      }}
                    />
                  </Grid>
                  
                  <Grid item xs={12}>
                    <Box display="flex" justifyContent="space-between" mt={2}>
                      <Button
                        variant="contained"
                        color="primary"
                        onClick={handleConvert}
                        disabled={loading}
                        startIcon={loading ? <CircularProgress size={20} /> : null}
                      >
                        Convert
                      </Button>
                      
                      <IconButton 
                        onClick={toggleFavorite}
                        color={isFavorite ? 'error' : 'default'}
                      >
                        {isFavorite ? <Favorite /> : <FavoriteBorder />}
                      </IconButton>
                    </Box>
                  </Grid>
                </Grid>
                
                {exchangeRate && (
                  <Box mt={3}>
                    <Typography variant="body2" color="textSecondary">
                      1 {fromCurrency} = {exchangeRate} {toCurrency}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      1 {toCurrency} = {(1 / exchangeRate).toFixed(6)} {fromCurrency}
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
            
            <Box mt={3}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Exchange Rate History
                  </Typography>
                  {historicalData ? (
                    <Line data={historicalData} options={chartOptions} />
                  ) : (
                    <Box display="flex" justifyContent="center" p={3}>
                      <CircularProgress />
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Popular Exchange Rates
                </Typography>
                
                {loading ? (
                  <Box display="flex" justifyContent="center" p={3}>
                    <CircularProgress />
                  </Box>
                ) : (
                  <Grid container spacing={2}>
                    {['EUR', 'GBP', 'JPY', 'AUD', 'CAD'].map((code) => (
                      code !== fromCurrency && (
                        <Grid item xs={12} sm={6} key={code}>
                          <Paper 
                            elevation={1} 
                            sx={{ 
                              p: 2, 
                              cursor: 'pointer',
                              '&:hover': { bgcolor: 'action.hover' },
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center'
                            }}
                            onClick={() => setToCurrency(code)}
                          >
                            <Box>
                              <Typography variant="subtitle1">
                                {fromCurrency} to {code}
                              </Typography>
                              <Typography variant="body2" color="textSecondary">
                                Loading...
                              </Typography>
                            </Box>
                            <Typography variant="h6">
                              {loading ? '...' : '...'}
                            </Typography>
                          </Paper>
                        </Grid>
                      )
                    ))}
                  </Grid>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {activeTab === 1 && (
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              My Favorite Pairs
            </Typography>
            
            {favorites.length === 0 ? (
              <Typography variant="body1" color="textSecondary" align="center" sx={{ p: 3 }}>
                No favorite currency pairs yet. Add some from the converter!
              </Typography>
            ) : (
              <Grid container spacing={2}>
                {favorites.map((fav) => (
                  <Grid item xs={12} sm={6} md={4} key={fav.id}>
                    <Paper 
                      elevation={fav.from_currency.code === fromCurrency && fav.to_currency.code === toCurrency ? 3 : 1}
                      sx={{ 
                        p: 2, 
                        cursor: 'pointer',
                        border: fav.from_currency.code === fromCurrency && fav.to_currency.code === toCurrency 
                          ? '1px solid #1976d2' 
                          : '1px solid rgba(0, 0, 0, 0.12)',
                        '&:hover': { bgcolor: 'action.hover' }
                      }}
                      onClick={() => handleFavoriteSelect(fav)}
                    >
                      <Box display="flex" justifyContent="space-between" alignItems="center">
                        <Box>
                          <Typography variant="subtitle1">
                            {fav.from_currency.code} to {fav.to_currency.code}
                          </Typography>
                          <Typography variant="body2" color="textSecondary">
                            {fav.from_currency.name} to {fav.to_currency.name}
                          </Typography>
                        </Box>
                        <IconButton 
                          color="error"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFromCurrency(fav.from_currency.code);
                            setToCurrency(fav.to_currency.code);
                            toggleFavorite();
                          }}
                        >
                          <Favorite />
                        </IconButton>
                      </Box>
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 2 && (
        <Card>
          <CardContent>
            <Box mb={3}>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Search currencies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <Search sx={{ mr: 1, color: 'text.secondary' }} />,
                }}
              />
            </Box>
            
            <Grid container spacing={2}>
              {filteredCurrencies.map((currency) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={currency.code}>
                  <Paper 
                    elevation={1} 
                    sx={{ 
                      p: 2, 
                      cursor: 'pointer',
                      '&:hover': { bgcolor: 'action.hover' }
                    }}
                    onClick={() => {
                      setFromCurrency(currency.code);
                      setActiveTab(0);
                    }}
                  >
                    <Box display="flex" alignItems="center">
                      <Box sx={{ mr: 2, fontSize: '1.5rem' }}>
                        {currency.flag_emoji}
                      </Box>
                      <Box>
                        <Typography variant="subtitle1">
                          {currency.code}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          {currency.name}
                        </Typography>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default CurrencyExchange;
