package com.example.banksystem3.client.controller;

import com.example.banksystem3.client.controller.admin.AdminDashboardController;

/**
 * An interface for controllers that can be navigated to from a parent controller.
 * This allows for a robust and decoupled way to handle "back" navigation.
 */
public interface Navigable {
    void setParentController(AdminDashboardController controller);
}