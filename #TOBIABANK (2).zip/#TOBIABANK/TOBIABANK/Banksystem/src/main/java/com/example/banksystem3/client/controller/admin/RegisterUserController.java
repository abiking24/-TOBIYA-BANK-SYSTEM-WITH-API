package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.client.utils.ValidationUtil;
import com.example.banksystem3.shared.Account;
import com.example.banksystem3.shared.Role;
import com.example.banksystem3.shared.User;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Callback;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Logger;

public class RegisterUserController implements Navigable {
    private static final Logger logger = Logger.getLogger(RegisterUserController.class.getName());

    // Personal Info
    @FXML private TextField fullNameField;
    @FXML private ComboBox<String> genderCombo;
    @FXML private DatePicker dobField;
    @FXML private TextField nationalIdField;
    @FXML private TextField phoneField;
    @FXML private TextField emailField;

    // Address Info
    @FXML private TextField addressField; // Street Address
    @FXML private TextField cityField;
    @FXML private TextField stateField;
    @FXML private TextField countryField;

    // Account Info
    @FXML private ComboBox<Account.AccountType> accountTypeCombo;
    @FXML private TextField initialDepositField;

    // Credentials
    @FXML private ComboBox<Role> roleCombo;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;

    // Controls
    @FXML private Button registerButton;
    @FXML private Label statusLabel;

    private AdminDashboardController parentController;

    @FXML
    public void initialize() {
        // Populate ComboBoxes
        genderCombo.setItems(FXCollections.observableArrayList("Male", "Female"));
        accountTypeCombo.setItems(FXCollections.observableArrayList(Account.AccountType.values()));
        roleCombo.setItems(FXCollections.observableArrayList(Role.values()));

        // Add listener to roleCombo to prevent selecting ADMIN
        roleCombo.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == Role.ADMIN) {
                AlertUtil.showError("Authorization Error", "Registration of ADMIN users is not authorized. Only CUSTOMER role is allowed.");
                roleCombo.setValue(Role.CUSTOMER); // Revert to Customer or clear
            }
        });

        // Set default selections
        genderCombo.setValue("Male");
        accountTypeCombo.getSelectionModel().selectFirst();
        roleCombo.setValue(Role.CUSTOMER);

        dobField.setEditable(false);

        LocalDate minDate = LocalDate.now().minusYears(18);

        dobField.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isAfter(minDate));
            }
        });
    }

    @FXML
    private void handleRegister() {
        if (!validateInputs()) {
            return;
        }

        try {
            // --- Create User Object ---
            User newUser = new User(
                    UUID.randomUUID().toString(),
                    usernameField.getText().trim(),
                    passwordField.getText(),
                    fullNameField.getText().trim(),
                    roleCombo.getValue()
            );

            // Set personal details
            newUser.setGender(genderCombo.getValue());
            newUser.setDateOfBirth(dobField.getValue().toString());
            newUser.setNationalId(nationalIdField.getText().trim());
            newUser.setPhone(phoneField.getText().trim());
            newUser.setEmail(emailField.getText().trim());

            // Set address details
            String street = addressField.getText().trim();
            String city = cityField.getText().trim();
            String state = stateField.getText().trim();
            String country = countryField.getText().trim();
            String fullAddress = String.join(", ", street, city, state, country);

            newUser.setAddress(fullAddress); // Combined address
            newUser.setStreetAddress(street);
            newUser.setCity(city);
            newUser.setState(state);
            newUser.setCountry(country);

            // --- Create Account Object (if customer) ---
            Account newAccount = null;
            if (newUser.isCustomer()) {
                newAccount = new Account(
                        UUID.randomUUID().toString(),
                        newUser.getUserId(),
                        "TEMP_ACC_NUM", // Server will generate the final number
                        accountTypeCombo.getValue(),
                        Double.parseDouble(initialDepositField.getText()),
                        new SimpleDateFormat("yyyy-MM-dd").format(new Date())
                );
            }

            // --- RMI Call ---
            boolean success = RMIClient.getInstance().getBankService().registerUser(newUser, newAccount);

            if (success) {
                AlertUtil.showSuccess("Registration Successful",
                        "User '" + newUser.getUsername() + "' has been registered successfully.");
                handleClearForm();
            } else {
                AlertUtil.showError("Registration Failed", "Username may already exist or an error occurred on the server.");
            }

        } catch (Exception e) {
            AlertUtil.showError("Error", "An unexpected error occurred during registration: " + e.getMessage());
            logger.severe("Registration exception: " + e.getMessage());
        }
    }

    private boolean validateInputs() {
        // Full Name
        if (fullNameField.getText().trim().isEmpty() || !ValidationUtil.isValidName(fullNameField.getText())) {
            return AlertUtil.showError("Validation Error", "Full Name is required and must contain only letters and spaces.");
        }
        // Gender
        if (genderCombo.getValue() == null) {
            return AlertUtil.showError("Validation Error", "Please select a gender.");
        }
        // DOB
        if (dobField.getValue() == null) {
            return AlertUtil.showError("Validation Error", "Date of Birth is required.");
        }
        if (dobField.getValue().isAfter(LocalDate.now().minusYears(18))) {
            return AlertUtil.showError("Validation Error", "User must be at least 18 years old.");
        }
        // Phone
        if (!ValidationUtil.isValidPhone(phoneField.getText())) {
            return AlertUtil.showError("Validation Error", "Please enter a valid phone number (e.g., 07... or +251...).");
        }
        // Email
        if (!emailField.getText().trim().isEmpty() && !ValidationUtil.isValidEmail(emailField.getText())) {
            return AlertUtil.showError("Validation Error", "Please enter a valid email address.");
        }
        // National ID
        if (!nationalIdField.getText().trim().isEmpty() && !ValidationUtil.isValidNationalId(nationalIdField.getText())) {
            return AlertUtil.showError("Validation Error", "National ID must be between 6 and 20 digits.");
        }

        // Account fields (if customer)
        if (accountTypeCombo.getValue() == null) {
            return AlertUtil.showError("Validation Error", "Account Type is required.");
        }
        if (!ValidationUtil.isPositiveDouble(initialDepositField.getText())) {
            return AlertUtil.showError("Validation Error", "Initial Deposit must be a valid positive number.");
        }
        double deposit = Double.parseDouble(initialDepositField.getText());
        double minBalance = accountTypeCombo.getValue().getMinimumBalance();
        if (deposit < minBalance) {
            return AlertUtil.showError("Validation Error", "Initial deposit of " + deposit + " is less than the minimum required (" + minBalance + ").");
        }

        // Credentials
        if (usernameField.getText().trim().isEmpty()) {
            return AlertUtil.showError("Validation Error", "Username is required.");
        }
        if (passwordField.getText().length() < 6) {
            return AlertUtil.showError("Validation Error", "Password must be at least 6 characters long.");
        }
        if (!passwordField.getText().equals(confirmPasswordField.getText())) {
            return AlertUtil.showError("Validation Error", "Passwords do not match.");
        }

        return true;
    }

    @FXML
    private void handleClearForm() {
        fullNameField.clear();
        genderCombo.getSelectionModel().clearSelection();
        dobField.setValue(null);
        nationalIdField.clear();
        phoneField.clear();
        emailField.clear();
        addressField.clear();
        cityField.clear();
        stateField.clear();
        countryField.clear();
        accountTypeCombo.getSelectionModel().clearSelection();
        initialDepositField.clear();
        roleCombo.setValue(Role.CUSTOMER);
        usernameField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        statusLabel.setText("");
    }

    @FXML
    private void handleBack() {
        if (parentController != null) {
            // Call the public method to navigate back to the main dashboard view
            parentController.showDefaultDashboardView();
        }
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.parentController = controller;
    }
}