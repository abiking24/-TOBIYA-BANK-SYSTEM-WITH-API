package com.example.banksystem3.client.utils;

import java.text.DecimalFormat;

/**
 * A utility class for formatting currency values consistently.
 * This centralizes the currency format for the entire application.
 */
public final class CurrencyUtil {

    private static final DecimalFormat ETB_FORMATTER = new DecimalFormat("#,##0.00 'ETB'");

    private CurrencyUtil() {
        // Private constructor for utility class
    }

    /**
     * Formats a double value into the standard Ethiopian Birr (ETB) currency format.
     * Example: 12345.67 -> "12,345.67 ETB"
     */
    public static String format(double value) {
        return ETB_FORMATTER.format(value);
    }
}