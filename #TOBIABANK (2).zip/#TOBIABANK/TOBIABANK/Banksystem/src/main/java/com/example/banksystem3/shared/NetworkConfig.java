package com.example.banksystem3.shared;

// For DEVELOPMENT ONLY - Private IP Ranges
public class NetworkConfig {
    // RFC 1918 Private Address Space (Safe for local/LAN)
    public static final String[] ALLOWED_IPS = {
        "127.0.0.1",        // Localhost
        "192.168.0.0/16",   // Home/Office networks
        "10.0.0.0/8",       // Large private networks
        "172.16.0.0/12"     // Private networks
    };
    
    // RMI Server Configuration
    public static final int RMI_PORT = 1099;
    public static final String RMI_HOST = "localhost"; // Change for network testing
    
    // Service Names
    public static final String BANK_SERVICE = "BankService";
    public static final String CURRENCY_SERVICE = "CurrencyExchangeService";
}
