package com.example.banksystem3.shared;

public enum Role {
    ADMIN,
    CUSTOMER
}