package com.example.banksystem3.client.model;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

public class ExchangeRate {
    private final SimpleStringProperty currency;
    private final SimpleDoubleProperty rate;

    public ExchangeRate(String currency, Double rate) {
        this.currency = new SimpleStringProperty(currency);
        this.rate = new SimpleDoubleProperty(rate);
    }

    public String getCurrency() {
        return currency.get();
    }

    public double getRate() {
        return rate.get();
    }
}