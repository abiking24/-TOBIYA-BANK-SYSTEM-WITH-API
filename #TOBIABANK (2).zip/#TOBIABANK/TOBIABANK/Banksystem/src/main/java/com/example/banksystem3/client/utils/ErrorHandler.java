package com.example.banksystem3.client.utils;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A centralized utility for handling and displaying application errors.
 * It logs the full exception and shows a user-friendly dialog.
 */
public final class ErrorHandler {

    private static final Logger logger = Logger.getLogger(ErrorHandler.class.getName());

    private ErrorHandler() {
        // Private constructor for utility class
    }

    /**
     * Handles an exception by logging it and displaying a detailed alert dialog.
     * This method is safe to call from any thread.
     *
     * @param title     The title for the alert dialog window.
     * @param message   A user-friendly message explaining what went wrong.
     * @param exception The exception that occurred.
     */
    public static void handleException(String title, String message, Exception exception) {
        // Log the full exception stack trace
        logger.log(Level.SEVERE, title + ": " + message, exception);

        // Show the alert on the JavaFX Application Thread
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(title);
            alert.setContentText(message);

            // Create an expandable Exception dialog.
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            exception.printStackTrace(pw);
            String exceptionText = sw.toString();

            alert.getDialogPane().setExpandableContent(new Label(exceptionText));
            alert.showAndWait();
        });
    }
}