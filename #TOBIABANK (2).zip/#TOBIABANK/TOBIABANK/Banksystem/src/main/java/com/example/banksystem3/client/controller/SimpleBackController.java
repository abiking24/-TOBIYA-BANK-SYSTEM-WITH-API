package com.example.banksystem3.client.controller;

import com.example.banksystem3.client.session.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent; // Import ActionEvent
import java.io.IOException;

public class SimpleBackController {

    @FXML
    private void handleBack(ActionEvent event) throws IOException { // Add ActionEvent parameter
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); // Get Node from event source
        Parent root;

        // Determine which dashboard to go back to
        if (SessionManager.getInstance().isAdmin()) {
            root = FXMLLoader.load(getClass().getResource(
                    "/com/example/banksystem3/view/admin/AdminDashboard.fxml"));
        } else {
            root = FXMLLoader.load(getClass().getResource(
                    "/com/example/banksystem3/view/customer/CustomerDashboard.fxml"));
        }

        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.centerOnScreen();
    }
}