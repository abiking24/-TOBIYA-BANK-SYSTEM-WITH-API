package com.example.banksystem3.server.auth;

import com.example.banksystem3.shared.User;
import com.example.banksystem3.shared.Role;
import java.util.*;

public class AuthService {
    private final Map<String, User> users;
    private final Map<String, String> sessions;

    public AuthService() {
        users = new HashMap<>();
        sessions = new HashMap<>();
        initializeUsers();
    }

    private void initializeUsers() {
        // Admin user - Keep this one so you can log in!
        users.put("admin", new User("U001", "admin", "admin123", "Admin User", Role.ADMIN));
        
        // Sample customers removed.
    }

    public User authenticate(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            // SECURITY UPDATE: Only allow the user with the username "admin" to have the ADMIN role.
            if (user.getRole() == Role.ADMIN && !"admin".equals(user.getUsername())) {
                // This prevents other users from being granted admin access, even if their role is misconfigured.
                return null; // Reject login
            }

            // Create a copy of the user object to avoid modifying the stored user
            // IMPORTANT: Do NOT overwrite the userId with a session ID. The client needs the real userId to fetch data.
            return new User(user.getUserId(), user.getUsername(), user.getPassword(), user.getFullName(), user.getRole());
        }
        return null;
    }

    public boolean addUser(User user) {
        if (!users.containsKey(user.getUsername())) {
            users.put(user.getUsername(), user);
            return true;
        }
        return false;
    }

    public boolean removeUser(String username) {
        if (users.containsKey(username)) {
            users.remove(username);
            return true;
        }
        return false;
    }

    public boolean logout(String userId) {
        // In a real app, we would invalidate the session here.
        // For now, we just return true.
        return true;
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users.values());
    }

    public boolean changePassword(String username, String oldPassword, String newPassword) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(oldPassword)) {
            user.setPassword(newPassword);
            return true;
        }
        return false;
    }

    public User getUserByCustomerId(String customerId) {
        for (User user : users.values()) {
            if (customerId.equals(user.getCustomerId())) {
                return user;
            }
        }
        return null;
    }

    public User getUserById(String userId) {
        for (User user : users.values()) {
            if (userId.equals(user.getUserId())) {
                return user;
            }
        }
        return null;
    }
}
