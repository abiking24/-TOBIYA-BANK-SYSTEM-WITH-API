package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.shared.Account;
import com.example.banksystem3.shared.BankService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;

import java.rmi.RemoteException;
import java.util.List;

public class ManageAccountController implements Navigable {

    @FXML
    private TableView<Account> accountTable;

    @FXML
    private TableColumn<Account, String> colAccountNumber;

    @FXML
    private TableColumn<Account, String> colAccountType;

    @FXML
    private TableColumn<Account, Double> colBalance;

    @FXML
    private TableColumn<Account, String> colStatus;

    @FXML
    private TextField accountNumberField;

    @FXML
    private TextField accountTypeField;

    @FXML
    private TextField balanceField;

    @FXML
    private TextField statusField;

    private BankService bankService;
    private ObservableList<Account> accountList = FXCollections.observableArrayList();
    private AdminDashboardController parentController;

    public void initialize() {
        bankService = RMIClient.getInstance().getBankService();
        setupTableColumns();
        loadAccounts();

        // Add a listener to update the form when a table row is selected
        accountTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        populateAccountDetails(newSelection);
                    } else {
                        clearForm();
                    }
                });
    }

    private void setupTableColumns() {
        colAccountNumber.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));
        colAccountType.setCellValueFactory(new PropertyValueFactory<>("type"));
        colBalance.setCellValueFactory(new PropertyValueFactory<>("balance"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void loadAccounts() {
        try {
            accountList.setAll(bankService.getAllAccounts());
            accountTable.setItems(accountList);
        } catch (RemoteException e) {
            showError("Failed to load accounts: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddAccount() {
        // This would typically open a new dialog to create an account
        showError("Add Account functionality is not implemented in this view.");
    }

    @FXML
    private void handleUpdateAccount() {
        Account selected = accountTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select an account to update.");
            return;
        }

        try {
            // Update account properties from text fields
            // This is a simplified example. You would have more robust validation.
            selected.setType(Account.AccountType.valueOf(accountTypeField.getText()));
            selected.setBalance(Double.parseDouble(balanceField.getText()));
            selected.setStatus(statusField.getText());

            bankService.updateAccount(selected);
            loadAccounts();
        } catch (Exception e) {
            showError("Failed to update account: " + e.getMessage());
        }
    }

    @FXML
    private void handleCloseAccount() {
        Account selected = accountTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select an account to close.");
            return;
        }

        Alert confirmDialog = new Alert(AlertType.CONFIRMATION);
        confirmDialog.setTitle("Confirm Account Closure");
        confirmDialog.setHeaderText("Close Account #" + selected.getAccountNumber());
        confirmDialog.setContentText("Are you sure you want to close this account?");
        
        confirmDialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    bankService.closeAccount(selected.getAccountId());
                    loadAccounts();
                } catch (RemoteException e) {
                    showError("Failed to close account: " + e.getMessage());
                }
            }
        });
    }

    @FXML
    private void handleDeleteAccount() {
        // Fix for FXML LoadException: Redirect old/mismatched FXML call to close account
        handleCloseAccount();
    }

    private void populateAccountDetails(Account account) {
        accountNumberField.setText(account.getAccountNumber());
        accountTypeField.setText(account.getType().toString());
        balanceField.setText(String.valueOf(account.getBalance()));
        statusField.setText(account.getStatus());
    }

    private void clearForm() {
        accountNumberField.clear();
        accountTypeField.clear();
        balanceField.clear();
        statusField.clear();
    }

    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.parentController = controller;
    }

    @FXML
    private void handleBack() {
        if (parentController != null) {
            parentController.showDefaultDashboardView();
        }
    }
    
    @FXML
    private void handleRefresh(ActionEvent event) {
        loadAccounts();
    }
    
    @FXML
    private void handleGenerateAccountNumber(ActionEvent event) {
        try {
            accountNumberField.setText(bankService.generateAccountNumber());
        } catch (RemoteException e) {
            showError("Failed to generate account number: " + e.getMessage());
        }
    }
}