package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.shared.Account;
import com.example.banksystem3.shared.Transaction;
import com.example.banksystem3.shared.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.util.StringConverter;
import javafx.scene.chart.NumberAxis;

import java.rmi.RemoteException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class DashboardViewController implements Navigable {

    @FXML private Label totalUsersLabel;
    @FXML private Label totalAccountsLabel;
    @FXML private Label totalBalanceLabel;
    @FXML private PieChart popularServicesChart;
    @FXML private BarChart<String, Number> yearlyIncomeChart;
    @FXML private LineChart<String, Number> mobileUsageChart;
    
    @FXML private ToggleButton dailyToggle;
    @FXML private ToggleButton monthlyToggle;
    @FXML private ToggleGroup timeFrameGroup;

    private AdminDashboardController parentController;
    private List<Transaction> allTransactions;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "ET")); // Ethiopia Locale

    @FXML
    public void initialize() {
        // Setup toggle group
        timeFrameGroup = new ToggleGroup();
        if (dailyToggle != null) dailyToggle.setToggleGroup(timeFrameGroup);
        if (monthlyToggle != null) monthlyToggle.setToggleGroup(timeFrameGroup);
        
        // Default to daily
        if (dailyToggle != null) dailyToggle.setSelected(true);

        // Customize Chart Axes
        setupChartAxes();

        loadDashboardData();
    }
    
    private void setupChartAxes() {
        if (yearlyIncomeChart != null) {
            NumberAxis yAxis = (NumberAxis) yearlyIncomeChart.getYAxis();
            yAxis.setLabel("Amount (ETB)");
            yAxis.setTickLabelFormatter(new StringConverter<Number>() {
                @Override
                public String toString(Number object) {
                    return String.format("%.0f ETB", object.doubleValue());
                }

                @Override
                public Number fromString(String string) {
                    return 0;
                }
            });
        }
    }
    
    @FXML
    private void handleTimeFrameChange() {
        if (allTransactions != null) {
            updateActivityChart(allTransactions);
        }
    }

    private void loadDashboardData() {
        try {
            List<User> users = RMIClient.getInstance().getBankService().getAllUsers();
            List<Account> accounts = RMIClient.getInstance().getBankService().getAllAccounts();
            allTransactions = RMIClient.getInstance().getBankService().getAllTransactions();

            // Update Labels
            totalUsersLabel.setText(String.valueOf(users.size()));
            totalAccountsLabel.setText(String.valueOf(accounts.size()));
            
            double totalBalance = accounts.stream().mapToDouble(Account::getBalance).sum();
            totalBalanceLabel.setText(String.format("ETB %,.2f", totalBalance)); // Format with commas

            // 1. MOST POPULAR BANKING SERVICES (Pie Chart)
            // Use Tobia Bank specific data simulation as requested
            Map<String, Long> serviceCounts = new TreeMap<>();
            serviceCounts.put("Tobia Mobile Money Transfer", 38L);
            serviceCounts.put("Account Balance Inquiry", 27L);
            serviceCounts.put("Bill Payments (Utilities)", 15L);
            serviceCounts.put("Airtime Purchase", 12L);
            serviceCounts.put("Loan Applications", 8L);
            

            ObservableList<PieChart.Data> popularServicesData = FXCollections.observableArrayList();
            serviceCounts.forEach((service, count) -> 
                popularServicesData.add(new PieChart.Data(service, count)));
            
            popularServicesChart.setData(popularServicesData);
            popularServicesChart.setTitle("Most Popular Mobile Banking Services");
            
            // Add tooltips to PieChart
            popularServicesChart.getData().forEach(data -> {
                double total = popularServicesChart.getData().stream().mapToDouble(PieChart.Data::getPieValue).sum();
                String percentage = String.format("%.1f%%", (data.getPieValue() / total * 100));
                Tooltip tooltip = new Tooltip(data.getName() + ": " + percentage);
                Tooltip.install(data.getNode(), tooltip);
            });


            // 2. YEARLY OVERALL INCOME ON DEPOSITS (Bar Chart)
            // Use Tobia Bank specific growth data as requested
            Map<String, Double> yearlyDeposits = new TreeMap<>();
            yearlyDeposits.put("2020", 45000000000.0);
            yearlyDeposits.put("2021", 89000000000.0);
            yearlyDeposits.put("2022", 156000000000.0);
            yearlyDeposits.put("2023", 240000000000.0);
            yearlyDeposits.put("2024", 380000000000.0);
            

            XYChart.Series<String, Number> incomeSeries = new XYChart.Series<>();
            incomeSeries.setName("Deposits (ETB)");
            yearlyDeposits.forEach((year, amount) -> {
                XYChart.Data<String, Number> data = new XYChart.Data<>(year, amount);
                incomeSeries.getData().add(data);
            });

            yearlyIncomeChart.getData().clear();
            yearlyIncomeChart.getData().add(incomeSeries);
            yearlyIncomeChart.setTitle("Tobia Mobile Banking Growth (Deposits)");
            
            // Add tooltips to BarChart
            for (XYChart.Series<String, Number> series : yearlyIncomeChart.getData()) {
                for (XYChart.Data<String, Number> data : series.getData()) {
                    Tooltip tooltip = new Tooltip(String.format("ETB %,.0f", data.getYValue().doubleValue()));
                    Tooltip.install(data.getNode(), tooltip);
                }
            }


            // 3. USING A MOBILE DEVICES IN BANKING (Line Chart) - Activity Trend
            updateActivityChart(allTransactions);


        } catch (RemoteException e) {
            AlertUtil.showError("Data Load Error", "Failed to load dashboard data: " + e.getMessage());
        }
    }
    
    private void updateActivityChart(List<Transaction> transactions) {
        if (mobileUsageChart == null) return;
        
        boolean isMonthly = monthlyToggle != null && monthlyToggle.isSelected();
        
        Map<String, Long> usageData = new TreeMap<>();
        
        // Use dummy data as requested
        if (isMonthly) {
            usageData.put("2024-01", 850000L);
            usageData.put("2024-02", 920000L);
            usageData.put("2024-03", 1100000L);
            usageData.put("2024-04", 1250000L);
            usageData.put("2024-05", 1400000L);
        } else {
            usageData.put("05-01", 45000L);
            usageData.put("05-02", 48000L);
            usageData.put("05-03", 52000L);
            usageData.put("05-04", 49000L);
            usageData.put("05-05", 55000L);
        }

        XYChart.Series<String, Number> usageSeries = new XYChart.Series<>();
        usageSeries.setName(isMonthly ? "Monthly Users" : "Daily Transactions");
        
        usageData.forEach((date, count) -> 
            usageSeries.getData().add(new XYChart.Data<>(date, count)));

        mobileUsageChart.getData().clear();
        mobileUsageChart.getData().add(usageSeries);
        mobileUsageChart.setTitle(isMonthly ? "Mobile User Growth (Monthly)" : "Mobile Transactions (Daily)");
        
        // Add tooltips to LineChart
        for (XYChart.Series<String, Number> series : mobileUsageChart.getData()) {
            for (XYChart.Data<String, Number> data : series.getData()) {
                Tooltip tooltip = new Tooltip(data.getXValue() + ": " + String.format("%,d", data.getYValue().longValue()));
                Tooltip.install(data.getNode(), tooltip);
            }
        }
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.parentController = controller;
    }
}