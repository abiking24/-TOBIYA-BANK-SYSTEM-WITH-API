package com.example.banksystem3.client.rmi;

import com.example.banksystem3.shared.BankService;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages the RMI connection to the server using the Singleton pattern.
 * This ensures a single, shared connection is used throughout the client application.
 */
public class RMIClient {

    private static final Logger logger = Logger.getLogger(RMIClient.class.getName());
    private static RMIClient instance;
    private BankService bankService;
    private boolean connected = false;

    // Private constructor to prevent direct instantiation
    private RMIClient() {
        connect("localhost", 1099);
    }

    /**
     * Gets the single instance of the RMIClient, creating it if it doesn't exist.
     *
     * @return The singleton instance of RMIClient.
     */
    public static synchronized RMIClient getInstance() {
        if (instance == null) {
            instance = new RMIClient();
        }
        return instance;
    }

    public void connect(String host, int port) {
        try {
            Registry registry = LocateRegistry.getRegistry(host, port);
            bankService = (BankService) registry.lookup("BankService");
            connected = true;
            logger.info("Successfully connected to RMI server at " + host + ":" + port);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "RMI connection failed", e);
            connected = false;
            bankService = null;
        }
    }

    public BankService getBankService() {
        // If not connected, try to reconnect automatically.
        if (!connected) {
            connect("localhost", 1099);
        }
        return bankService;
    }

    public boolean isConnected() {
        return connected;
    }

    public void disconnect() {
    }
}