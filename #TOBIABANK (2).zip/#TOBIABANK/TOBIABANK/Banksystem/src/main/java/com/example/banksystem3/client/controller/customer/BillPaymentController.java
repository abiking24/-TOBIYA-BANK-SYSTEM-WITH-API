package com.example.banksystem3.client.controller.customer;

import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.session.SessionManager;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.shared.Account;
import com.example.banksystem3.shared.BankService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

import java.rmi.RemoteException;
import java.util.List;

public class BillPaymentController {

    @FXML private ComboBox<Account> accountCombo;
    @FXML private ComboBox<String> billerCombo;
    @FXML private Label referenceLabel;
    @FXML private TextField referenceField;
    @FXML private TextField amountField;

    private BankService bankService;

    @FXML
    public void initialize() {
        bankService = RMIClient.getInstance().getBankService();
        loadUserAccounts();
        setupBillers();
    }

    private void loadUserAccounts() {
        try {
            String userId = SessionManager.getInstance().getCurrentUser().getUserId();
            List<Account> accounts = bankService.getCustomerAccounts(userId);
            accountCombo.setItems(FXCollections.observableArrayList(accounts));
            
            // Custom converter to show Account Number in ComboBox
            accountCombo.setConverter(new StringConverter<Account>() {
                @Override
                public String toString(Account account) {
                    return account == null ? "" : account.getAccountNumber() + " (" + String.format("%.2f", account.getBalance()) + " ETB)";
                }

                @Override
                public Account fromString(String string) {
                    return null; // Not needed
                }
            });

            if (!accounts.isEmpty()) {
                accountCombo.getSelectionModel().selectFirst();
            }
        } catch (RemoteException e) {
            AlertUtil.showError("Error", "Failed to load accounts: " + e.getMessage());
        }
    }

    private void setupBillers() {
        billerCombo.setItems(FXCollections.observableArrayList(
            "Ethio Telecom (Airtime/Bill)",
            "Ethiopian Electric Utility (EEU)",
            "Addis Ababa Water (AAWSA)",
            "DSTV Ethiopia",
            "Ethiopian Airlines",
            "Traffic Penalty"
        ));

        billerCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                updateReferenceLabel(newVal);
            }
        });
        
        billerCombo.getSelectionModel().selectFirst();
    }

    private void updateReferenceLabel(String biller) {
        if (biller.contains("Ethio Telecom")) referenceLabel.setText("Phone Number:");
        else if (biller.contains("Electric")) referenceLabel.setText("Contract Number:");
        else if (biller.contains("Water")) referenceLabel.setText("Customer ID:");
        else if (biller.contains("DSTV")) referenceLabel.setText("Smart Card Number:");
        else if (biller.contains("Airlines")) referenceLabel.setText("Booking Reference:");
        else if (biller.contains("Traffic")) referenceLabel.setText("Ticket Number:");
        else referenceLabel.setText("Reference Number:");
    }

    @FXML
    private void handlePayBill() {
        Account selectedAccount = accountCombo.getValue();
        String biller = billerCombo.getValue();
        String reference = referenceField.getText().trim();
        String amountStr = amountField.getText().trim();

        if (selectedAccount == null || biller == null || reference.isEmpty() || amountStr.isEmpty()) {
            AlertUtil.showError("Validation Error", "Please fill in all fields.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);
            
            boolean success = bankService.payBill(selectedAccount.getAccountId(), biller, reference, amount);
            
            if (success) {
                AlertUtil.showInfo("Success", "Payment of " + amount + " ETB to " + biller + " successful!");
                referenceField.clear();
                amountField.clear();
                loadUserAccounts(); // Refresh balance
            } else {
                AlertUtil.showError("Payment Failed", "Insufficient funds or system error.");
            }
        } catch (NumberFormatException e) {
            AlertUtil.showError("Validation Error", "Invalid amount format.");
        } catch (RemoteException e) {
            AlertUtil.showError("System Error", "Payment processing failed: " + e.getMessage());
        }
    }
}