package com.example.banksystem3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

class APP extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create UI without FXML for testing
        Label titleLabel = new Label("Banking System Login");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        javafx.scene.control.PasswordField passwordField = new javafx.scene.control.PasswordField();
        passwordField.setPromptText("Password");

        Button loginButton = new Button("Login");
        Label statusLabel = new Label("Enter credentials");

        loginButton.setOnAction(e -> {
            if (usernameField.getText().equals("admin") && passwordField.getText().equals("admin123")) {
                statusLabel.setText("Login successful!");
                statusLabel.setStyle("-fx-text-fill: green;");
            } else {
                statusLabel.setText("Invalid credentials");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        });

        VBox root = new VBox(20, titleLabel, usernameField, passwordField, loginButton, statusLabel);
        root.setStyle("-fx-padding: 40; -fx-alignment: center;");

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setTitle("Banking System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}