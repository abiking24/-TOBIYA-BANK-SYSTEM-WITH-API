package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.session.SessionManager;
import com.example.banksystem3.client.utils.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class ViewLogsController implements Navigable {

    @FXML private ListView<String> logsListView;
    @FXML private TextArea logDetailsArea;
    @FXML private ComboBox<String> logLevelCombo;
    @FXML private Label totalLogsLabel;
    @FXML private Label infoLogsLabel;
    @FXML private Label warnLogsLabel;
    @FXML private Label errorLogsLabel;
    
    private ObservableList<String> logsList;
    private AdminDashboardController adminDashboardController;

    @FXML
    public void initialize() {
        logsList = FXCollections.observableArrayList();
        logsListView.setItems(logsList);

        // Ensure connection exists before proceeding
        if (!RMIClient.getInstance().isConnected()) {
            AlertUtil.showError("Connection Error", "Cannot load logs. Not connected to server.");
            return;
        }

        logLevelCombo.setItems(FXCollections.observableArrayList("ALL", "INFO", "WARN", "ERROR", "TRANSACTION"));
        logLevelCombo.setValue("ALL");
        
        logLevelCombo.valueProperty().addListener((obs, oldVal, newVal) -> filterLogs(newVal));

        loadLogs();

        // Set up selection listener
        logsListView.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        logDetailsArea.setText(newSelection);
                    }
                });
    }

    private void loadLogs() {
        try {
            List<String> logs = RMIClient.getInstance().getBankService().getSystemLogs();
            logsList.setAll(logs);
            updateStatistics(logs);

            if (!logs.isEmpty()) {
                logsListView.getSelectionModel().select(0);
                logDetailsArea.setText(logs.get(0));
            }

        } catch (Exception e) {
            AlertUtil.showError("Error", "Failed to load logs: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void filterLogs(String level) {
        try {
            List<String> allLogs = RMIClient.getInstance().getBankService().getSystemLogs();
            if ("ALL".equals(level)) {
                logsList.setAll(allLogs);
            } else if ("TRANSACTION".equals(level)) {
                 List<String> filtered = allLogs.stream()
                        .filter(log -> log.contains("Deposit") || log.contains("Withdrawal") || log.contains("Transfer"))
                        .collect(Collectors.toList());
                logsList.setAll(filtered);
            } else {
                List<String> filtered = allLogs.stream()
                        .filter(log -> log.contains("[" + level + "]"))
                        .collect(Collectors.toList());
                logsList.setAll(filtered);
            }
            
            if (!logsList.isEmpty()) {
                logsListView.getSelectionModel().select(0);
            } else {
                logDetailsArea.clear();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateStatistics(List<String> logs) {
        long infoCount = logs.stream().filter(l -> l.contains("[INFO]")).count();
        long warnCount = logs.stream().filter(l -> l.contains("[WARN]")).count();
        long errorCount = logs.stream().filter(l -> l.contains("[ERROR]")).count();
        
        if (totalLogsLabel != null) totalLogsLabel.setText(String.valueOf(logs.size()));
        if (infoLogsLabel != null) infoLogsLabel.setText(String.valueOf(infoCount));
        if (warnLogsLabel != null) warnLogsLabel.setText(String.valueOf(warnCount));
        if (errorLogsLabel != null) errorLogsLabel.setText(String.valueOf(errorCount));
    }

    @FXML
    private void handleRefresh() {
        loadLogs();
        AlertUtil.showInfo("Refreshed", "Logs refreshed successfully.");
    }

    @FXML
    private void handleClearLogs() {
        logDetailsArea.clear();
    }

    @FXML
    private void handleBack() throws IOException {
        if (adminDashboardController != null) {
            adminDashboardController.showDefaultDashboardView();
        }
    }

    @FXML
    private void handleExport() {
        AlertUtil.showInfo("Export", "Export feature coming soon!");
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.adminDashboardController = controller;
    }
}