package com.example.banksystem3.client;

public class ClientMain {
    public static void main(String[] args) {
        ClientApp.main(args);
    }
}
