package com.example.banksystem3.server.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtil {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static String formatLog(String level, String message) {
        return String.format("[%s] [%s] %s", sdf.format(new Date()), level, message);
    }

    public static String formatInfo(String message) {
        return formatLog("INFO", message);
    }
}