package com.example.banksystem3.client;

public class ClientLauncher {
    public static void main(String[] args) {
        ClientMain.main(args);
    }
}
