package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.shared.BankService;
import com.example.banksystem3.shared.Transaction;
import com.example.banksystem3.shared.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.*;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.fxml.FXML;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class TobiaDashboardController implements Navigable {

    @FXML
    private VBox mainContainer;

    private AdminDashboardController parentController;

    // Tobia Bank Colors
    private final Color TOBIA_BLUE = Color.rgb(0, 86, 179);
    private final Color TOBIA_GREEN = Color.rgb(40, 167, 69);
    private final Color TOBIA_ORANGE = Color.rgb(255, 107, 53);
    private final Color TOBIA_PURPLE = Color.rgb(106, 76, 147);
    private final Color TOBIA_GRAY = Color.rgb(108, 117, 125);
    private final Color BACKGROUND = Color.rgb(245, 245, 245);

    @FXML
    public void initialize() {
        mainContainer.setBackground(new Background(new BackgroundFill(BACKGROUND, CornerRadii.EMPTY, Insets.EMPTY)));
        
        try {
            BankService bankService = RMIClient.getInstance().getBankService();
            List<Transaction> transactions = bankService.getAllTransactions();
            List<User> users = bankService.getAllUsers();

            VBox header = createHeader();
            GridPane chartsGrid = createChartsGrid(transactions, users);
            
            mainContainer.getChildren().addAll(header, chartsGrid);

        } catch (RemoteException e) {
            AlertUtil.showError("Connection Error", "Failed to load dashboard data from the server.");
            e.printStackTrace();
        }
    }

    private VBox createHeader() {
        Label title = new Label("TOBIA BANK MOBILE BANKING");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setTextFill(TOBIA_BLUE);
        
        Label subtitle = new Label("የቶቢያ ባንክ ሞባይል ባንኪንግ - 2024 አገልግሎት ምደባ");
        subtitle.setFont(Font.font("Nyala", 16));
        subtitle.setTextFill(Color.DARKGRAY);
        
        Label reportTitle = new Label("2024 Performance Report & Analytics");
        reportTitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        reportTitle.setTextFill(Color.GRAY);
        
        VBox header = new VBox(10, title, subtitle, reportTitle);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(20));
        header.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        
        Region line = new Region();
        line.setPrefHeight(2);
        line.setBackground(new Background(new BackgroundFill(TOBIA_BLUE, CornerRadii.EMPTY, Insets.EMPTY)));
        header.getChildren().add(line);
        
        return header;
    }

    private GridPane createChartsGrid(List<Transaction> transactions, List<User> users) {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(20);
        grid.setVgap(20);
        
        VBox chart1Container = createPieChart(transactions);
        GridPane.setConstraints(chart1Container, 0, 0);
        
        VBox chart2Container = createBarChart(users);
        GridPane.setConstraints(chart2Container, 1, 0);
        
        VBox chart3Container = createAreaChart(transactions);
        GridPane.setConstraints(chart3Container, 0, 1, 2, 1);
        
        VBox chart4Container = createStackedBarChart(users);
        GridPane.setConstraints(chart4Container, 0, 2);
        
        VBox chart5Container = createLineChart(transactions);
        GridPane.setConstraints(chart5Container, 1, 2);
        
        grid.getChildren().addAll(chart1Container, chart2Container, chart3Container, chart4Container, chart5Container);
        
        return grid;
    }

    private VBox createPieChart(List<Transaction> transactions) {
        Label title = new Label("MOST POPULAR MOBILE BANKING SERVICES");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        title.setTextFill(TOBIA_BLUE);
        
        PieChart pieChart = new PieChart();
        pieChart.setTitle("Service Distribution (%)");
        
        Map<String, Long> serviceCounts = transactions.stream()
                .collect(Collectors.groupingBy(t -> t.getType().getDisplayName(), Collectors.counting()));

        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        serviceCounts.forEach((service, count) -> pieData.add(new PieChart.Data(service, count)));
        
        pieChart.setData(pieData);
        
        return createChartContainer(title, pieChart);
    }

    private VBox createBarChart(List<User> users) {
        Label title = new Label("MOBILE BANKING USER GROWTH");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        title.setTextFill(TOBIA_BLUE);
        
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Number of Users");
        
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Yearly User Growth");
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Tobia Mobile Users");
        
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        Map<String, Long> userGrowth = users.stream()
                .collect(Collectors.groupingBy(u -> yearFormat.format(java.sql.Date.valueOf(u.getRegistrationDate())), Collectors.counting()));

        new TreeMap<>(userGrowth).forEach((year, count) -> {
            series.getData().add(new XYChart.Data<>(year, count));
        });
        
        barChart.getData().add(series);
        
        return createChartContainer(title, barChart);
    }

    private VBox createAreaChart(List<Transaction> transactions) {
        Label title = new Label("YEARLY OVERALL INCOME ON DEPOSITS (ብር)");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        title.setTextFill(TOBIA_BLUE);
        
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Income (Birr)");
        
        AreaChart<String, Number> areaChart = new AreaChart<>(xAxis, yAxis);
        areaChart.setTitle("Deposit Income Trend");
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Deposit Income");
        
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        Map<String, Double> yearlyDeposits = transactions.stream()
                .filter(t -> t.getType() == Transaction.TransactionType.DEPOSIT)
                .collect(Collectors.groupingBy(
                        t -> yearFormat.format(t.getTimestamp()),
                        Collectors.summingDouble(Transaction::getAmount)
                ));

        new TreeMap<>(yearlyDeposits).forEach((year, amount) -> {
            series.getData().add(new XYChart.Data<>(year, amount));
        });
        
        areaChart.getData().add(series);

        return createChartContainer(title, areaChart);
    }

    private VBox createStackedBarChart(List<User> users) {
        Label title = new Label("USER DEMOGRAPHICS BY AGE GROUP");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        title.setTextFill(TOBIA_BLUE);
        
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Number of Users");
        
        StackedBarChart<String, Number> stackedBarChart = new StackedBarChart<>(xAxis, yAxis);
        stackedBarChart.setTitle("Age Distribution");
        
        // This is a simplified age calculation. A real one would be more robust.
        long group18_25 = users.stream().filter(u -> u.getDateOfBirth() != null && calculateAge(u.getDateOfBirth()) >= 18 && calculateAge(u.getDateOfBirth()) <= 25).count();
        long group26_35 = users.stream().filter(u -> u.getDateOfBirth() != null && calculateAge(u.getDateOfBirth()) >= 26 && calculateAge(u.getDateOfBirth()) <= 35).count();
        long group36_50 = users.stream().filter(u -> u.getDateOfBirth() != null && calculateAge(u.getDateOfBirth()) >= 36 && calculateAge(u.getDateOfBirth()) <= 50).count();
        long group50plus = users.stream().filter(u -> u.getDateOfBirth() != null && calculateAge(u.getDateOfBirth()) > 50).count();

        XYChart.Series<String, Number> series18_25 = new XYChart.Series<>();
        series18_25.setName("18-25 Years");
        series18_25.getData().add(new XYChart.Data<>("Age Groups", group18_25));
        
        XYChart.Series<String, Number> series26_35 = new XYChart.Series<>();
        series26_35.setName("26-35 Years");
        series26_35.getData().add(new XYChart.Data<>("Age Groups", group26_35));
        
        XYChart.Series<String, Number> series36_50 = new XYChart.Series<>();
        series36_50.setName("36-50 Years");
        series36_50.getData().add(new XYChart.Data<>("Age Groups", group36_50));
        
        XYChart.Series<String, Number> series50plus = new XYChart.Series<>();
        series50plus.setName("50+ Years");
        series50plus.getData().add(new XYChart.Data<>("Age Groups", group50plus));
        
        stackedBarChart.getData().addAll(series18_25, series26_35, series36_50, series50plus);
        
        return createChartContainer(title, stackedBarChart);
    }

    private VBox createLineChart(List<Transaction> transactions) {
        Label title = new Label("MOBILE PLATFORM USAGE TREND");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        title.setTextFill(TOBIA_BLUE);
        
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Month");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Number of Transactions");
        
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Monthly Transaction Volume");
        
        SimpleDateFormat monthFormat = new SimpleDateFormat("yyyy-MM");
        Map<String, Long> monthlyTransactions = transactions.stream()
                .collect(Collectors.groupingBy(t -> monthFormat.format(t.getTimestamp()), Collectors.counting()));

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Transactions");
        
        new TreeMap<>(monthlyTransactions).forEach((month, count) -> {
            series.getData().add(new XYChart.Data<>(month, count));
        });
        
        lineChart.getData().add(series);
        
        return createChartContainer(title, lineChart);
    }

    private VBox createChartContainer(Label title, Chart chart) {
        VBox container = new VBox(10, title, chart);
        container.setPadding(new Insets(15));
        container.setBackground(new Background(new BackgroundFill(Color.WHITE, new CornerRadii(10), Insets.EMPTY)));
        container.setStyle("-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        return container;
    }

    private int calculateAge(String dob) {
        try {
            java.time.LocalDate birthDate = java.time.LocalDate.parse(dob);
            return java.time.Period.between(birthDate, java.time.LocalDate.now()).getYears();
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.parentController = controller;
    }
}