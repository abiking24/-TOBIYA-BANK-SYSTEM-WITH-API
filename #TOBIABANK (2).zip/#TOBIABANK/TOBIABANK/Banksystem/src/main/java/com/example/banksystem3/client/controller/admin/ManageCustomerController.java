package com.example.banksystem3.client.controller.admin;

import com.example.banksystem3.client.controller.Navigable;
import com.example.banksystem3.client.rmi.RMIClient;
import com.example.banksystem3.client.utils.AlertUtil;
import com.example.banksystem3.shared.BankService;
import com.example.banksystem3.shared.User;
import com.example.banksystem3.shared.Account;
import com.example.banksystem3.shared.Customer;
import com.example.banksystem3.shared.Role;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.control.DateCell;
import javafx.util.Callback;

import java.rmi.RemoteException;
import java.time.LocalDate;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.UUID;

public class ManageCustomerController implements Navigable {

    @FXML
    private TableView<User> customerTable;

    @FXML
    private TableColumn<User, String> colCustomerId;

    @FXML
    private TableColumn<User, String> colFullName;

    @FXML
    private TableColumn<User, String> colUsername;

    @FXML
    private TableColumn<User, String> colPhone;

    @FXML
    private TableColumn<User, String> colEmail;

    @FXML
    private TableColumn<User, String> colAddress;

    @FXML
    private TableColumn<User, String> colDob;

    @FXML
    private TableColumn<User, String> colRegDate;

    @FXML
    private TableColumn<User, String> colStatus;

    @FXML
    private TableColumn<User, String> colAccountNumberCustomer;

    @FXML
    private TableColumn<User, String> colAccountTypeCustomer;

    @FXML
    private TableColumn<User, Number> colInitialDepositCustomer;

    @FXML
    private TableColumn<User, String> colNationalIdCustomer;

    @FXML
    private TableColumn<User, String> colGenderCustomer;

    @FXML
    private TableColumn<User, String> colStreetAddressCustomer;

    @FXML
    private TableColumn<User, String> colCityCustomer;

    @FXML
    private TableColumn<User, String> colStateCustomer;

    @FXML
    private TableColumn<User, String> colCountryCustomer;

    @FXML
    private TextField customerIdField;

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField emailField;
    
    @FXML
    private TextField phoneField;
    
    @FXML
    private TextField nationalIdField;
    
    @FXML
    private ComboBox<String> genderCombo;
    
    @FXML
    private DatePicker dobField;
    
    @FXML
    private TextArea addressField;
    
    @FXML
    private TextField cityField;
    
    @FXML
    private TextField stateField;
    
    @FXML
    private TextField countryField;
    
    @FXML
    private ComboBox<String> statusCombo;
    
    @FXML
    private Button btnClearForm;

    private BankService bankService;

    private ObservableList<User> customerList = FXCollections.observableArrayList();
    private final Map<String, String> accountNumberByUserId = new HashMap<>();
    private AdminDashboardController parentController;

    public void initialize() {
        bankService = RMIClient.getInstance().getBankService();
        
        if (genderCombo != null) genderCombo.setItems(FXCollections.observableArrayList("Male", "Female"));
        if (statusCombo != null) statusCombo.setItems(FXCollections.observableArrayList("Active", "Inactive"));

        if (dobField != null) {
            final LocalDate maxDob = LocalDate.now().minusYears(18);
            dobField.setEditable(false);
            dobField.setDayCellFactory(new Callback<>() {
                @Override
                public DateCell call(DatePicker picker) {
                    return new DateCell() {
                        @Override
                        public void updateItem(LocalDate date, boolean empty) {
                            super.updateItem(date, empty);
                            if (empty || date == null) return;
                            setDisable(date.isAfter(maxDob));
                        }
                    };
                }
            });
        }
        
        setupTableColumns();
        loadCustomers();

        // Add listener to populate form when a customer is selected
        customerTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                handleSelectCustomer();
            } else {
                handleClearForm();
            }
        });
    }

    private void setupTableColumns() {
        if (colCustomerId != null) colCustomerId.setCellValueFactory(new PropertyValueFactory<>("userId"));
        if (colFullName != null) colFullName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        if (colUsername != null) colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        if (colPhone != null) colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        if (colEmail != null) colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        if (colAddress != null) colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        if (colDob != null) colDob.setCellValueFactory(new PropertyValueFactory<>("dateOfBirth"));
        if (colRegDate != null) colRegDate.setCellValueFactory(new PropertyValueFactory<>("registrationDate"));
        if (colStatus != null) colStatus.setCellValueFactory(new PropertyValueFactory<>("role"));

        if (colAccountNumberCustomer != null) {
            colAccountNumberCustomer.setCellValueFactory(cd -> new SimpleStringProperty(formatAccountNumber(cd.getValue())));
        }
        if (colAccountTypeCustomer != null) {
            colAccountTypeCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getAccountType() : null)));
        }
        if (colInitialDepositCustomer != null) {
            colInitialDepositCustomer.setCellValueFactory(cd -> {
                Double bal = cd.getValue() != null ? cd.getValue().getBalance() : null;
                return new SimpleDoubleProperty(bal != null ? bal : 0.0);
            });
        }
        if (colNationalIdCustomer != null) {
            colNationalIdCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getNationalId() : null)));
        }
        if (colGenderCustomer != null) {
            colGenderCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getGender() : null)));
        }
        if (colStreetAddressCustomer != null) {
            colStreetAddressCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getStreetAddress() : null)));
        }
        if (colCityCustomer != null) {
            colCityCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getCity() : null)));
        }
        if (colStateCustomer != null) {
            colStateCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getState() : null)));
        }
        if (colCountryCustomer != null) {
            colCountryCustomer.setCellValueFactory(cd -> new SimpleStringProperty(safe(cd.getValue() != null ? cd.getValue().getCountry() : null)));
        }
    }

    private void loadCustomers() {
        try {
            // Filter to show only users with the CUSTOMER role
            List<User> customerUsers = bankService.getAllUsers().stream()
                    .filter(user -> user.getRole() == Role.CUSTOMER)
                    .collect(Collectors.toList());

            accountNumberByUserId.clear();
            for (User user : customerUsers) {
                enrichCustomerRow(user);
            }

            customerList.setAll(customerUsers);
            customerTable.setItems(customerList);
        } catch (RemoteException e) {
            showError("Failed to load customers: " + e.getMessage());
        }
    }

    private void enrichCustomerRow(User user) {
        if (user == null || bankService == null) return;
        try {
            // Try to use already-present fields from User first.
            // If address is a single string like "street, city, state, country", split it.
            populateAddressParts(user);

            // Account info
            try {
                List<Account> accounts = bankService.getCustomerAccounts(user.getUserId());
                if (accounts != null && !accounts.isEmpty()) {
                    Account a = accounts.get(0);
                    // Account number (4-digit format if possible)
                    // We store it in streetAddress field? No. Just keep in a derived column.
                    // For account type, store display name in User.accountType for table.
                    if (a.getType() != null) {
                        user.setAccountType(a.getType().getDisplayName());
                    }
                    user.setBalance(a.getBalance());
                    if (user.getUserId() != null) {
                        accountNumberByUserId.put(user.getUserId(), a.getAccountNumber());
                    }
                }
            } catch (Exception ignore) {
                // keep row partially filled
            }
        } catch (Exception ignore) {
            // keep row partially filled
        }
    }

    private void populateAddressParts(User user) {
        if (user == null) return;

        // If explicit fields exist, prefer them
        boolean hasExplicit = (user.getStreetAddress() != null && !user.getStreetAddress().isBlank())
                || (user.getCity() != null && !user.getCity().isBlank())
                || (user.getState() != null && !user.getState().isBlank())
                || (user.getCountry() != null && !user.getCountry().isBlank());
        if (hasExplicit) return;

        String full = user.getAddress();
        if (full == null || full.isBlank()) return;

        String[] parts = full.split(",\\s*");
        if (parts.length > 0) user.setStreetAddress(parts[0]);
        if (parts.length > 1) user.setCity(parts[1]);
        if (parts.length > 2) user.setState(parts[2]);
        if (parts.length > 3) user.setCountry(parts[3]);
    }

    private String formatAccountNumber(User user) {
        if (user == null) return "";

        String raw = user.getUserId() != null ? accountNumberByUserId.get(user.getUserId()) : null;
        if (raw == null || raw.isBlank()) return "";
        try {
            int n = Integer.parseInt(raw.replaceAll("\\D", ""));
            return String.format("%04d", n % 10000);
        } catch (Exception e) {
            return raw;
        }
    }

    private String safe(String v) {
        return v == null ? "" : v;
    }

    @FXML
    private void handleClearForm() {
        customerIdField.clear();
        fullNameField.clear();
        emailField.clear();
        if (phoneField != null) phoneField.clear();
        if (nationalIdField != null) nationalIdField.clear();
        if (addressField != null) addressField.clear();
        if (cityField != null) cityField.clear();
        if (stateField != null) stateField.clear();
        if (countryField != null) countryField.clear();
        if (genderCombo != null) genderCombo.getSelectionModel().clearSelection();
        if (dobField != null) dobField.setValue(null);
        if (statusCombo != null) statusCombo.getSelectionModel().clearSelection();
        customerTable.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleUpdateCustomer() {
        User selected = customerTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a customer to update.");
            return;
        }

        // Validation
        String name = fullNameField.getText().trim();
        if (name.isEmpty()) {
            showError("Full Name cannot be empty.");
            return;
        }

        if (dobField != null) {
            LocalDate dob = dobField.getValue();
            if (dob == null) {
                showError("Date of Birth is required.");
                return;
            }
            if (dob.isAfter(LocalDate.now().minusYears(18))) {
                showError("User must be at least 18 years old.");
                return;
            }
        }

        // Assemble the full address from all fields
        String street = addressField.getText().trim();
        String city = cityField.getText().trim();
        String state = stateField.getText().trim();
        String country = countryField.getText().trim();
        String fullAddress = String.join(", ", street, city, state, country);

        try {
            // Create a Customer DTO to send to the server
            Customer customerToUpdate = new Customer(
                selected.getUserId(),
                name,
                phoneField.getText(),
                fullAddress,
                dobField.getValue() != null ? dobField.getValue().toString() : ""
            );

            boolean success = bankService.updateCustomer(customerToUpdate);

            if (success) {
                // Manually update the local User object to reflect changes in the UI
                // This is a workaround because the server's `updateCustomer` does not
                // update the `User` object that the table is populated from.
                selected.setFullName(name);
                selected.setPhone(phoneField.getText());
                selected.setAddress(fullAddress);
                if (dobField.getValue() != null) {
                    selected.setDateOfBirth(dobField.getValue().toString());
                }

                customerTable.refresh();
                AlertUtil.showInfo("Success", "Customer details updated. Note: Login details are not affected.");
            } else {
                showError("Failed to update customer on the server.");
            }
        } catch (Exception e) {
            showError("Failed to update customer: " + e.getMessage());
        }
    }

    @FXML
    private void handleDeleteCustomer() {
        User selected = customerTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("Please select a customer to delete.");
            return;
        }

        if (AlertUtil.showConfirmation("Delete Customer", "Are you sure you want to delete " + selected.getFullName() + "? This may not delete their login credentials.")) {
            try {
                boolean success = bankService.deleteCustomer(selected.getUserId());
                if (success) {
                    customerList.remove(selected); // Manually remove from the client-side list
                    AlertUtil.showInfo("Success", "Customer details have been deleted.");
                } else {
                    showError("Could not delete customer. They may have active accounts.");
                }
            } catch (Exception e) {
                showError("Failed to delete customer: " + e.getMessage());
            }
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleSelectCustomer() {
        User selected = customerTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            customerIdField.setText(String.valueOf(selected.getUserId()));
            fullNameField.setText(selected.getFullName());
            emailField.setText(selected.getEmail());
            phoneField.setText(selected.getPhone());

            // Parse the full address string and populate individual fields
            String fullAddress = selected.getAddress();
            if (fullAddress != null && !fullAddress.isEmpty()) {
                String[] parts = fullAddress.split(",\\s*");
                addressField.setText(parts.length > 0 ? parts[0] : "");
                cityField.setText(parts.length > 1 ? parts[1] : "");
                stateField.setText(parts.length > 2 ? parts[2] : "");
                countryField.setText(parts.length > 3 ? parts[3] : "");
            }

            if (dobField != null && selected.getDateOfBirth() != null) {
                try {
                    dobField.setValue(LocalDate.parse(selected.getDateOfBirth()));
                } catch (Exception e) { /* ignore parse error */ }
            }
        }
    }

    @Override
    public void setParentController(AdminDashboardController controller) {
        this.parentController = controller;
    }
    
    @FXML
    private void handleBack() {
        if (parentController != null) {
            parentController.showDefaultDashboardView();
        }
    }
    
    @FXML
    private void handleRefresh(ActionEvent event) {
        loadCustomers();
    }
    
    @FXML
    private void handleGenerateId(ActionEvent event) {
        customerIdField.setText("CUST-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
    }

    @FXML
    private void handleGenerateAccountNumber(ActionEvent event) {
        // Fix for FXML LoadException: Redirect mismatched FXML call to generate ID
        handleGenerateId(event);
    }
    
    @FXML
    private void handleSearch(ActionEvent event) {
        // Search logic to be implemented
    }
    
    @FXML
    private void handleRefreshAccounts(ActionEvent event) {
        loadCustomers();
    }
    
    @FXML
    private void handleDeleteAccount(ActionEvent event) {
        // This is a placeholder. In a real app, you would get the selected account
        // from the accounts table and call a service to delete it.
        showError("Delete account functionality is not fully implemented.");
    }
    
    @FXML
    private void handleAddAccount(ActionEvent event) {
        // This should likely open a new dialog or navigate to a different screen
        System.out.println("Add account button clicked.");
    }
    
    @FXML
    private void handleCreateAccount(ActionEvent event) {
        // This should likely open a new dialog or navigate to a different screen
        System.out.println("Create account button clicked.");
    }
}