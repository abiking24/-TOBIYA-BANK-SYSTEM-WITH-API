module com.example.banksystem3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.rmi;
    requires java.logging;
    requires java.sql;
    requires java.desktop;
    requires com.google.gson;

    // Open packages to JavaFX
    opens com.example.banksystem3.client to javafx.fxml, javafx.base;
    opens com.example.banksystem3.client.controller to javafx.fxml, javafx.base;
    opens com.example.banksystem3.client.model to javafx.base, com.google.gson;
    opens com.example.banksystem3.client.controller.admin to javafx.fxml, javafx.base;
    opens com.example.banksystem3.client.controller.customer to javafx.fxml, javafx.base;
    opens com.example.banksystem3.client.controller.login to javafx.fxml, javafx.base;

    // Export packages
    exports com.example.banksystem3.client;
    exports com.example.banksystem3.client.controller;
    exports com.example.banksystem3.client.model;
    exports com.example.banksystem3.client.controller.admin;
    exports com.example.banksystem3.client.controller.customer;
    exports com.example.banksystem3.client.controller.login;
    exports com.example.banksystem3.shared;
}